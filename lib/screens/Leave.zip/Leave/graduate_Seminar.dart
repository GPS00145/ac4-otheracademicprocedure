import 'package:flutter/material.dart';

void main() {
  runApp(GraduateSeminar());
}

class GraduateSeminar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            'Graduate Seminar',
            style: TextStyle(color: Colors.white, fontSize: 20.0),
          ),
          backgroundColor: Colors.black,
          leading: IconButton(
            icon: Icon(Icons.arrow_back , color: Colors.white),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        body: Container(
          color: Colors.white,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(40.0), // Adjust overall padding
              child: Column(
                children: [
                  // Image and student name in same container
                  Container(
                    width: 380.0,
                    height: 240.0, // Adjusted height to accommodate both image and text
                    decoration: BoxDecoration(
                      color: Colors.orange[50],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    padding: EdgeInsets.all(15.0), // Adjust padding
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Image with circular edges
                        Container(
                          width: 150.0,
                          height: 150.0,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: Image.asset(
                              'assets/unknown.jpg', // Path to your image asset
                              fit: BoxFit.cover, // Ensure the image covers the container
                            ),
                          ),
                        ),
                        SizedBox(height: 10.0), // Add spacing between image and text
                        // Student info
                        Text(
                          'Student Name',
                          style: TextStyle(fontSize: 16.0), // Increase font size
                        ),
                        Text(
                          'CSE Student',
                          style: TextStyle(fontSize: 16.0),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15.0),

                  // Top right square with seminar info
                  Container(
                    width: 380.0, // Keep width same
                    height: 80.0, // Increase height
                    decoration: BoxDecoration(
                      color: Colors.orange[50],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    padding: EdgeInsets.all(15.0), // Adjust padding
                    child: Column(
                      children: [
                        Text(
                          '[Graduate Seminar Date]',
                          style: TextStyle(fontSize: 16.0),
                        ),
                        Text(
                          '[12/01/2024]',
                          style: TextStyle(fontSize: 16.0),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
