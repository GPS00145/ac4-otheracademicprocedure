import 'package:flutter/material.dart';

void main() {
  runApp(FacultyHomepage());
}

class FacultyHomepage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: Text(
            'Dashboard',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
        ),
        body: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(30.0), // Add padding around the orange container
              child: SizedBox(
                width: 230, // Reduce the width of the orange container
                child: Container(
                  height: 350,

                  decoration: BoxDecoration(
                    color: Colors.orange[50], // Change to orange color
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0), // Add padding inside the orange container
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 180, // Reduce the width of the profile picture container
                          height: 240,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('assets/profile_pic.png'),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'Faculty Name',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 25.0, // Reduce font size
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20), // Add spacing between the orange container and buttons
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly, // Align buttons horizontally
              children: [
                SizedBox(
                  width: 400, // Set the width of both buttons
                  child: ElevatedButton(
                    onPressed: () {
                      // Add your button onPressed logic here
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.white, // Set button color to white
                      textStyle: TextStyle(
                        color: Colors.black,
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 18), // Adjust padding
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                        side: BorderSide(color: Colors.orange), // Add orange border
                      ),
                    ),
                    child: Text(
                      'Approve Assistantship',
                      style: TextStyle(
                        fontSize: 25, // Reduce font size
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: 400, // Set the width of both buttons
                  child: ElevatedButton(
                    onPressed: () {
                      // Add your button onPressed logic here
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.white, // Set button color to white
                      textStyle: TextStyle(
                        color: Colors.black,
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 18), // Adjust padding
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                        side: BorderSide(color: Colors.orange), // Add orange border
                      ),
                    ),
                    child: Text(
                      'Verify Leave',
                      style: TextStyle(
                        fontSize: 25, // Reduce font size
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
