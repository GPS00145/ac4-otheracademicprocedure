import 'package:flutter/material.dart';

void main() {
  runApp(AssistantClaimStatus());
}

class AssistantClaimStatus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assistantship Status'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 380.0,
              decoration: BoxDecoration(
                color: Colors.orange[50],
                borderRadius: BorderRadius.circular(10.0),
              ),
              padding: EdgeInsets.all(30),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      'assets/unknown.jpg',
                      width: 150,
                      height: 150,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text('STUDENT NAME', style: TextStyle(fontSize: 20)),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              width: MediaQuery.of(context).size.width - 40,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.orange[50],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Table(
                border: TableBorder.all(color: Colors.black),
                children: [
                  TableRow(
                    children: [
                      TableCell(
                        child: Container(
                          height: 40,
                          padding: EdgeInsets.all(8),
                          child: Text(
                            'NAME',
                            style: TextStyle(fontSize: 20),
                          ),
                        ),
                      ),
                      TableCell(
                        child: Container(
                          height: 40,
                          padding: EdgeInsets.all(8),
                          child: Text(
                            '',
                            style: TextStyle(fontSize: 20),
                          ),
                        ),
                      ),
                      TableCell(
                        child: Container(
                          height: 40,
                          padding: EdgeInsets.all(8),
                          child: Text(
                            '',
                            style: TextStyle(fontSize: 20),
                          ),
                        ),
                      ),
                    ],
                  ),
                  buildTableRow('NAME', ''),
                  buildTableRow('ROLL NO', ''),
                  buildTableRow('DATE APPLIED', ''),
                  buildTableRowWithStatus('FORM STATUS'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  TableRow buildTableRow(String title, String content) {
    return TableRow(
      children: [
        TableCell(
          child: Container(
            height: 40,
            padding: EdgeInsets.all(8),
            child: Text(
              title,
              style: TextStyle(fontSize: 20),
            ),
          ),
        ),
        TableCell(
          child: Container(
            height: 40,
            padding: EdgeInsets.all(8),
            child: Text(
              content,
              style: TextStyle(fontSize: 20),
            ),
          ),
        ),
        TableCell(
          child: Container(
            height: 40,
            padding: EdgeInsets.all(8),
            child: SizedBox(),
          ),
        ),
      ],
    );
  }

  TableRow buildTableRowWithStatus(String title) {
    return TableRow(
      children: [
        TableCell(
          child: Container(
            height: 40,
            padding: EdgeInsets.all(8),
            child: Text(
              title,
              style: TextStyle(fontSize: 20),
            ),
          ),
        ),
        TableCell(
          child: Container(
            height: 40,
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                Checkbox(
                  value: false,
                  onChanged: (newValue) {
                    // Handle the checkbox value change
                    // You can use state management to update the value
                  },
                ),
                Text('Approve', style: TextStyle(fontSize: 20)),
              ],
            ),
          ),
        ),
        TableCell(
          child: Container(
            height: 40,
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                Checkbox(
                  value: false,
                  onChanged: (newValue) {
                    // Handle the checkbox value change
                    // You can use state management to update the value
                  },
                ),
                Text('Reject', style: TextStyle(fontSize: 20)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
