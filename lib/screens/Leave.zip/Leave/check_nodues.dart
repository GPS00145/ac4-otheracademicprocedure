import 'package:flutter/material.dart';

void main() {
  runApp(CheckNoDues());
}

class CheckNoDues extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: NoDuesScreen(),
      ),
    );
  }
}

class NoDuesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.only(top: 15, left: 15),
            color: Colors.black,
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  color: Colors.white,
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      'CHECK NO DUES',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Container(
                margin: EdgeInsets.all(16),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Table(
                  border: TableBorder.all(color: Colors.black),
                  children: [
                    _buildTableRow(['S.No', '1', '2', '3']),
                    _buildTableRow(['Student Name', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildTableRow(['Roll No.', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildTableRow(['Mess Due', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildTableRow(['Library Due', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildTableRow(['Hostel Due', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildTableRow(['Placement Due', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildTableRow(['Total Due', _buildTextField(), _buildTextField(), _buildTextField()]),
                    _buildApproveDenyRow(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  TableRow _buildTableRow(List<dynamic> rowData) {
    return TableRow(
      children: List.generate(
        rowData.length,
            (index) => TableCell(
          child: Container(
            padding: EdgeInsets.all(8),
            width: index == 0 ? 120.0 : null,
            child: Center(child: _handleTableCellContent(rowData[index])),
          ),
        ),
      ),
    );
  }

  Widget _handleTableCellContent(dynamic content) {
    if (content is String) {
      return Text(
        content,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.black,
        ),
      );
    } else if (content is Widget) {
      return content;
    }
    return Container();
  }

  Widget _buildTextField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: TextField(
        decoration: InputDecoration(
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  TableRow _buildApproveDenyRow() {
    return TableRow(
      children: [
        Container(
          padding: EdgeInsets.all(8),
          width: 120.0,
          child: Center(
            child: Text(
              'Approve/Deny',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
        ),
        _buildCheckboxCell(),
        _buildCheckboxCell(),
        _buildCheckboxCell(),
      ],
    );
  }

  Widget _buildCheckboxCell() {
    return TableCell(
      child: Container(
        padding: EdgeInsets.all(8),
        child: Center(
          child: CheckboxWidget(),
        ),
      ),
    );
  }
}

class CheckboxWidget extends StatefulWidget {
  @override
  _CheckboxWidgetState createState() => _CheckboxWidgetState();
}

class _CheckboxWidgetState extends State<CheckboxWidget> {
  bool isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Checkbox(
      value: isChecked,
      onChanged: (bool? value) {
        setState(() {
          isChecked = value ?? false;
        });
      },
    );
  }
}
