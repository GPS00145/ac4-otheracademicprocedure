import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fusion/services/leave_services.dart';
import 'package:http/http.dart' as http;


class LeaveStatus extends StatefulWidget {
  @override
  _LeaveStatusState createState() => _LeaveStatusState();
}

class _LeaveStatusState extends State<LeaveStatus> {

  LeaveService _leaveService = LeaveService();

  @override
  void initState() {
    super.initState();
    _fetchLeaves();
  }

  void _fetchLeaves() async {
    http.Response response = await _leaveService.getLeaves();

    Map<String, dynamic> leaveList = json.decode(response.body)['payload'];
    print(leaveList);

  }

  @override
  Widget build(BuildContext context) {
    // Define a function to handle delete operation
    void deleteEntry(int index) {
      // Implement the delete logic here
      print('Deleted entry at index: $index');
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Leave Status',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          // Orange container for the icon and student name
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.orange[50],
                borderRadius: BorderRadius.circular(10.0), // Set the border radius
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Container(
                    width: 320,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/unknown.jpg', // Replace 'unknown.jpg' with your image asset path
                          width: 120.0,
                          height: 170.0,
                        ),
                        SizedBox(height: 20),
                        Text(
                          'STUDENT NAME',
                          style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // SizedBox to separate the containers vertically
          SizedBox(height: 20),

          // Orange container for the table
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.orange[50],
                borderRadius: BorderRadius.circular(10.0), // Set the border radius
              ),
              child: SingleChildScrollView(
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('S.No.')),
                    DataColumn(label: Text('Applied At')),
                    DataColumn(label: Text('Details')),
                    DataColumn(label: Text('Status')),
                    DataColumn(label: Text('Delete')),
                  ],
                  rows: [
                    DataRow(cells: [
                      DataCell(Text('1')),
                      DataCell(Text('2023-10-26')),
                      DataCell(Text('Casual Leave')),
                      DataCell(Text('Pending')),
                      DataCell(IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          // Call deleteEntry function with index 1
                          deleteEntry(1);
                        },
                      )),
                    ]),
                    DataRow(cells: [
                      DataCell(Text('2')),
                      DataCell(Text('2023-10-24')),
                      DataCell(Text('Medical Leave')),
                      DataCell(Text('Approved')),
                      DataCell(IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          // Call deleteEntry function with index 2
                          deleteEntry(2);
                        },
                      )),
                    ]),
                    DataRow(cells: [
                      DataCell(Text('3')),
                      DataCell(Text('2023-10-23')),
                      DataCell(Text('Sick Leave')),
                      DataCell(Text('Declined')),
                      DataCell(IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          // Call deleteEntry function with index 3
                          deleteEntry(3);
                        },
                      )),
                    ]),
                  ],
                ),
              ),
            ),
          ),

          // Button row
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Approved: 1',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Text(
                  'Pending: 1',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Text(
                  'Declined: 1',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
